{
            "name": "Python Debugger: Current File",
            "type": "debugpy",
            "request": "launch",
            "program": "${/workspaces/9780357881019-fundamentals-of-python-3e-2b6fd664-dac0-4f8f-b2c9-086856301713/chapter0/ex00/student/example.py}",
            "console": "integratedTerminal"
        }